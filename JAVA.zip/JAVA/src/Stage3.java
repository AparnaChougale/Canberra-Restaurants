// Author: Aparna Chougale
// Date created: 16 April 2017
// Date last changed: 20 April 2017
// This program calculates number of days a person have been alive from date of birth to second date.
// Input: dates.txt, Output: displays person's name, Date of birth, current date, & days alive on respective  and draw bar-chart after selecting person's name from JList.

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Panel;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Vector;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Stage3 extends JFrame implements ListSelectionListener 
{

	// Global constants
	public static final Font fFontLabel= new Font("Tahoma", Font.BOLD, 12);
	int month[]={0,31,28,31,30,31,30,31,31,30,31,30,31};
	int iDay1,iMonth1,iYear1,iDay2,iMonth2,iYear2;
	
	
	// Global GUI elements
	private ButtonGroup rButtonGroup = new ButtonGroup();
	private JTextField jTextFieldSecondDate;
	private JLabel jLabelDaysAlive; 
	private JLabel jLabelDaysAliveResult;
	private JRadioButton jRadioBtnList;
	private JRadioButton jRadiobtnEnter;
	private JPanel jPanel;
	private JLabel jLabel_Name;
	private JLabel jLabel_Name1;
	JList<String> jListName ;
	private Vector<Person> vecPerson;
	Panel BarGraphPanel;
	BarGraphPanel pnl;
	
	// Global variables
	public int iDaysAlive,i,j;
	public static String sa2D[][]=new String[2][10];
	public static String name;
	public static String line1;
	public static BufferedReader br = null;
	int selectedIndex = -1;
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Stage3 window = new Stage3();
					window.setTitle("Days Alive Calculator - Stage 3");
					window.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	
	
	}

	/**
	 * Create the application.
	 */

	public Stage3() {
		//initialize();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1167, 742);
		jPanel = new JPanel();
		jPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		//jPanel.setBounds(190, 11, 383, 248);
		setContentPane(jPanel);
		jPanel.setLayout(null);

		// Initialize vector that will hold the data
		vecPerson = new Vector<Person>();
		
		//initializing GUI elements
		JLabel jLabelName = new JLabel("Select Person's Name :");
		jLabelName.setFont(fFontLabel);
		jLabelName.setBounds(38, 0, 173, 39);
		jPanel.add(jLabelName);
		
		jRadioBtnList = new JRadioButton("Select Second Date From JList");
		jRadioBtnList.setSelected(true);
		jRadioBtnList.setFont(new Font("Tahoma", Font.BOLD, 12));
		jRadioBtnList.setBounds(284, 32, 305, 40);
		jPanel.add(jRadioBtnList);
		
		jRadiobtnEnter = new JRadioButton("Enter Second Date into TextBox and Select any name from the above list:");
		jRadiobtnEnter.setFont(new Font("Tahoma", Font.BOLD, 12));
		jRadiobtnEnter.setBounds(284, 75, 488, 43);
		jPanel.add(jRadiobtnEnter);
		
		//add Radio buttons to a group
		rButtonGroup.add(jRadioBtnList);
		rButtonGroup.add(jRadiobtnEnter);
		
		jTextFieldSecondDate = new JTextField();
		jTextFieldSecondDate.setBounds(797, 77, 163, 40);
		jPanel.add(jTextFieldSecondDate);
		jTextFieldSecondDate.setColumns(10);
		
		jLabelDaysAlive = new JLabel("Days Alive :");
		jLabelDaysAlive.setForeground(Color.DARK_GRAY);
		jLabelDaysAlive.setFont(new Font("Tahoma", Font.BOLD, 13));
		jLabelDaysAlive.setBounds(325, 171, 90, 58);
		jPanel.add(jLabelDaysAlive);
		
		jLabelDaysAliveResult = new JLabel("0");
		jLabelDaysAliveResult.setForeground(Color.MAGENTA);
		jLabelDaysAliveResult.setFont(new Font("Tahoma", Font.BOLD, 16));
		jLabelDaysAliveResult.setBounds(425, 170, 173, 58);
		jPanel.add(jLabelDaysAliveResult);
		
		JLabel jLabelDateFormate = new JLabel("(DD,MM,YYYY)");
		jLabelDateFormate.setEnabled(false);
		jLabelDateFormate.setBounds(830, 117, 86, 23);
		jPanel.add(jLabelDateFormate);
		
		jLabel_Name = new JLabel("Name:");
		jLabel_Name.setFont(new Font("Tahoma", Font.BOLD, 13));
		jLabel_Name.setBounds(325, 142, 78, 26);
		jPanel.add(jLabel_Name);
		
		jLabel_Name1 = new JLabel("---");
		jLabel_Name1.setForeground(Color.BLUE);
		jLabel_Name1.setFont(new Font("Tahoma", Font.BOLD, 14));
		jLabel_Name1.setBounds(413, 141, 171, 28);
		jPanel.add(jLabel_Name1);
		
		
		// Quit button with event handler to exit
		JButton jButtonQuit = new JButton("Quit");
		jButtonQuit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		jButtonQuit.setFont(fFontLabel);
		jButtonQuit.setBounds(535, 633, 103, 34);
		jPanel.add(jButtonQuit);
		
				
		
		// added person's names to jList
		DefaultListModel<String> listModel=new DefaultListModel<String>();
		read();
		for(Person p:vecPerson){
			listModel.addElement(p.getName());
		}
		
		jListName = new JList<String>(listModel);
		jListName.setFont(new Font("Tahoma", Font.BOLD, 13));
		jListName.setBounds(38, 37, 173, 224);
		jListName.addListSelectionListener( this);
		jPanel.add(jListName);
	
		BarGraphPanel = new Panel();
		BarGraphPanel.setBounds(10, 270, 1123, 337);
		jPanel.add(BarGraphPanel);
	
	}

	
	//list event handle which retrives and pass the values of dates fron vector respect to selected name from list
	public void valueChanged(ListSelectionEvent e) 
	{
		//String date2; 
    	String s=(String) jListName.getSelectedValue();
    	jLabel_Name1.setText(s);
		
    	int index = jListName.getSelectedIndex();  	
    	if(index != selectedIndex){
    		
    		selectedIndex = index;
    		int[] values = new int[vecPerson.size()];
    		String[] names = new String[vecPerson.size()];
    		int result = 0;
    		int i = 0;
    		
    		for(Person p:vecPerson)
    		{  int res=0;
    			
    			if (jRadiobtnEnter.isSelected())
    			{			 
    				try{
   			        // read second date from text file(dates.txt)
    					String date2=jTextFieldSecondDate.getText().trim();
   			      //	jLabelCurrentDate1.setText(date2);
   			       res = extInputs(p.getDate1(),date2 );
    				}
    				catch(Exception ee){
    					jLabelDaysAliveResult.setText("Enter Valid Date");
    					if(pnl != null){
    						BarGraphPanel.remove(pnl);
    						pnl = null;
    						BarGraphPanel.repaint();
    					}
    					return;
    				}
   			       	
   			 	}	
    			else
    			{   			
    				
    		    	
    		    	//	jLabelDateOfBirth1.setText(p.getDate1());
    					//jLabelCurrentDate1.setText(p.getDate2());
    		    	    		    	
    				res = extInputs(p.getDate1(), p.getDate2());
    				
    				
    			}
    			values[i] = res;
    			names[i] = p.getName()+"("+res+")";
    			if(i == selectedIndex)
    			{
    				result = res;
    			}
    			i++;
    			
    		}
    	if(pnl != null)
    	{
    		BarGraphPanel.remove(pnl);
    	}
    		pnl = new BarGraphPanel(values, names, "BarChart", selectedIndex );
    		//pnl.setSize(graphPanel.getWidth(), graphPanel.getHeight());
    		BarGraphPanel.setLayout(new BorderLayout());
    		BarGraphPanel.add(pnl);
    		jLabelDaysAliveResult.setText(""+result);
    	}
    	
    
	}

	//function to check for Leap Year
		int isLeap(int iYear)
		    {
		        if((iYear%400==0) || ((iYear%100!=0)&&(iYear%4==0)))
		            return 29;
		        else
		            return 28;
		    }
		 
		
		//function for date validation  
		boolean dateValidate(int iDate, int iMonth, int iYear)
		    {
		        month[2]=isLeap(iYear);
		        if(iMonth<0 || iMonth>12 || iDate<0 || iDate>month[iMonth] || iYear<0 || iYear>9999)
		            return false;
		        else
		            return true;
		    }
		 
		
		//function for calculating number of days from Birth year to Second date year.
		int Days(int iDate, int iMonth, int iYear)
		    {
		        int iDays=0;
		        month[2]=isLeap(iYear);
		        for(int i=1;i<iMonth;i++)
		        {
		        	iDays=iDays+month[i];
		        }
		        iDays=iDays+iDate;
		        for(int i=1;i<iYear;i++)
		        {
		            if(isLeap(i)==29)
		            	iDays=iDays+366;
		            else
		            	iDays=iDays+365;
		        }
		        return iDays;
		    }
		 
		
		//Extracting dates/inputs and perform operations returns days alive
		public int extInputs(String DOB,String SecondDate)
		{
			String date1,date2;
			date1=DOB;
			date2=SecondDate;
			
			//reading birth date from text file(dates.txt)
         	date1=DOB.trim();
         	//jLabelDateOfBirth1.setText(date1);
         	
         	//String date1=br.readLine().trim();
	        int iTemp1,iTemp2;
	 
	        //extracting day1
	        iTemp1=date1.indexOf(",");
	        int iDay1=Integer.parseInt(date1.substring(0,iTemp1));
	 
	        //extracting month1
	        iTemp2=date1.lastIndexOf(",");
	        int iMonth1=Integer.parseInt(date1.substring(iTemp1+1,iTemp2));
	 
	        //extracting year1
	        int iYear1=Integer.parseInt(date1.substring(iTemp2+1));
			   // read second date from text file(dates.txt)
		       	date2=SecondDate.trim();
		       	//jLabelCurrentDate1.setText(date2);
		     
		    //extracting the second date
		        iTemp1=date2.indexOf(",");
		        int iDay2=Integer.parseInt(date2.substring(0,iTemp1));
		        iTemp2=date2.lastIndexOf(",");
		        int iMonth2=Integer.parseInt(date2.substring(iTemp1+1,iTemp2));
		        int iYear2=Integer.parseInt(date2.substring(iTemp2+1));
		 
				
	        //Validating both dates
	        if(dateValidate(iDay1,iMonth1,iYear1)==true && dateValidate(iDay2,iMonth2,iYear2)==true)
	        {
	            int iDate1=Days(iDay1,iMonth1,iYear1);
	            int iDate2=Days(iDay2,iMonth2,iYear2);
	            iDaysAlive= (Math.abs(iDate1-iDate2))+1;
	            //return iDaysAlive;
	           // jLabelDaysAliveResult.setText(String.valueOf(iDaysAlive));
	         }
	       else {
	          System.out.println("Invalid Date"); }
	        
	        
	        return iDaysAlive;
			
			
		}
		
		
		// pass the corresponding string value i.e. selected name and Set days alive to labels
		
		
		
		// reads and stores all the data into two diametion array
		private void read()
		{
			//String array[][]=new String[10][10];
			
			
			try {   
				String sLine;
						
				br = new BufferedReader(new FileReader("dates.txt"));
				while ((sLine = br.readLine()) != null) 
				{
					String[] arr=sLine.split(";");
					String name=arr[0];
					
					String date1=arr[1];
					
					String date2=arr[2];
					
					this.vecPerson.add(new Person(name,date1,date2));
					
					
				}
				
			} catch (IOException e)
				{
					e.printStackTrace();
				} 
				
		
		}




		

}




