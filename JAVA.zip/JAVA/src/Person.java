// Author: Aparna Chougale
// Date created: 16 April 2017
// Date last changed: 20 April 2017


public class Person {

	// TODO Auto-generated method stub

			String sName = "";
			String date1 = "";
			String date2 = "";
			//double dDistance = 0.0;

			/**
			 * Creator method.
			 * 
			 * @param sName
			 * @param sConstellation
			 * @param dDistance
			 */
			public Person(String sName, String date1, String date2)
			{
				this.sName = sName;
				this.date1 = date1;
				this.date2 = date2;
			}
			
			
			public String getName() {
				return sName;
			}
			public void setName(String name) {
				this.sName = name;
			}
			public String getDate1() {
				return date1;
			}
			public void setDate1(String date1) {
				this.date1 = date1;
			}
			public String getDate2() {
				return date2;
			}
			public void setDate2(String date2) {
				this.date2 = date2;
			}
			
}
