// Author: Aparna Chougale
// Date created: 13 April 2017
// Date last changed: 14 April 2017
// This program calculates number of days a person have been alive from date of birth to second date.
// Input: user entered input via console, Output: days alive.


import java.io.*;

public class Stage1 
{
	// Global Variables
	int month[]={0,31,28,31,30,31,30,31,31,30,31,30,31};
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	
	
	//function to check for Leap Year
	int isLeap(int iYear)
	    {
	        if((iYear%400==0) || ((iYear%100!=0)&&(iYear%4==0)))
	            return 29;
	        else
	            return 28;
	    }
	 
	
	//function for date validation  
	boolean dateValidate(int iDate, int iMonth, int iYear)
	    {
	        month[2]=isLeap(iYear);
	        if(iMonth<0 || iMonth>12 || iDate<0 || iDate>month[iMonth] || iYear<0 || iYear>9999)
	            return false;
	        else
	            return true;
	    }
	 
	
	//function for calculating number of days from Birth year to Second date year.
	int Days(int iDate, int iMonth, int iYear)
	    {
	        int iDays=0;
	        month[2]=isLeap(iYear);
	        for(int i=1;i<iMonth;i++)
	        {
	        	iDays=iDays+month[i];
	        }
	        iDays=iDays+iDate;
	        for(int i=1;i<iYear;i++)
	        {
	            if(isLeap(i)==29)
	            	iDays=iDays+366;
	            else
	            	iDays=iDays+365;
	        }
	        return iDays;
	    }
	 
	
	// main method
	public static void main(String args[])throws IOException
	    {
			// class object
			Stage1 obj = new Stage1();
			System.out.println("DAYS ALIVE CALCULATOR - Stage 1"+"\n\n");
		
			System.out.print("Enter the Person's name: ");
	        String sName=br.readLine().trim();
			
			// read first date or birth date
	        System.out.print("\n"+"Enter the Date of Birth in (dd/mm/yyyy) format: ");
	        String date1=br.readLine().trim();
	        int iTemp1,iTemp2;
	 
	        //extracting day1
	        iTemp1=date1.indexOf("/");
	        int iDay1=Integer.parseInt(date1.substring(0,iTemp1));
	 
	        //extracting month1
	        iTemp2=date1.lastIndexOf("/");
	        int iMonth1=Integer.parseInt(date1.substring(iTemp1+1,iTemp2));
	 
	        //extracting year1
	        int iYear1=Integer.parseInt(date1.substring(iTemp2+1));
	 
	        // read second date
	        System.out.print("\n"+"Enter the 2nd date in (dd/mm/yyyy) format: ");
	        String date2=br.readLine().trim();
	        
	        //extracting the second date
	        iTemp1=date2.indexOf("/");
	        int iDay2=Integer.parseInt(date2.substring(0,iTemp1));
	        iTemp2=date2.lastIndexOf("/");
	        int iMonth2=Integer.parseInt(date2.substring(iTemp1+1,iTemp2));
	        int iYear2=Integer.parseInt(date2.substring(iTemp2+1));
	 
	        //Validating both dates
	        if(obj.dateValidate(iDay1,iMonth1,iYear1)==true && obj.dateValidate(iDay2,iMonth2,iYear2)==true)
	        {
	            int iDate1=obj.Days(iDay1,iMonth1,iYear1);
	            int iDate2=obj.Days(iDay2,iMonth2,iYear2);
	            int iDaysAlive= (Math.abs(iDate1-iDate2))+1;
	            
	            System.out.print("\n"+" Person name : "+sName.toUpperCase() +"\n"+" Days alive : "+ iDaysAlive+" days.");
	        }
	        else
	            System.out.println("Invalid Date");
	    }
	
	
}
	


