import java.awt.*;
import java.util.*;
import java.io.*;
import java.awt.event.*;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class BarGraphPanel extends JPanel {
	
	private String[] sNames;
	String sTitle;
	int[] iValues;
	int highlight;
	
		
	public BarGraphPanel(int[] v, String[] n, String t, int highlight)
	{
		iValues = v;
		sNames = n;
		sTitle = t;
		highlight=highlight;
		
	 }
	
	public void paintComponent(Graphics g) {
	    super.paintComponent(g);
	    if (iValues == null || iValues.length == 0)
	      return;
	    double minValue = 0;
	    double maxValue = 0;
	    for (int i = 0; i < iValues.length; i++) {
	      if (minValue > iValues[i])
	        minValue = iValues[i];
	      if (maxValue < iValues[i])
	        maxValue = iValues[i];
	    }

	    Dimension d = getSize();
	    int clientWidth = d.width;
	    int clientHeight = d.height;
	    int barWidth = clientWidth / iValues.length;

	    Font titleFont = new Font("Tahoma", Font.BOLD, 20);
	    FontMetrics titleFontMetrics = g.getFontMetrics(titleFont);
	    Font labelFont = new Font("Tahoma", Font.PLAIN, 9);
	    FontMetrics labelFontMetrics = g.getFontMetrics(labelFont);

	    int titleWidth = titleFontMetrics.stringWidth(sTitle);
	    int y = titleFontMetrics.getAscent();
	    int x = (clientWidth - titleWidth) / 2;
	    g.setFont(titleFont);
	    g.drawString(sTitle, x, y);

	    int top = titleFontMetrics.getHeight();
	    int bottom = labelFontMetrics.getHeight();
	    if (maxValue == minValue)
	      return;
	    double scale = (clientHeight - top - bottom) / (maxValue - minValue);
	    y = clientHeight - labelFontMetrics.getDescent();
	    g.setFont(labelFont);

	    for (int i = 0; i < iValues.length; i++) {
	      int valueX = i * barWidth + 1;
	      int valueY = top;
	      int height = (int) (iValues[i] * scale);
	      if (iValues[i] >= 0)
	        valueY += (int) ((maxValue - iValues[i]) * scale);
	      else {
	        valueY += (int) (maxValue * scale);
	        height = -height;
	      }

	      if( i == highlight){
	    	  g.setColor(Color.green);
	      }
	      else{
	    	  g.setColor(Color.CYAN);
	      }
	      
	      g.fillRect(valueX, valueY, barWidth - 2, height);
	      g.setColor(Color.DARK_GRAY);
	      g.drawRect(valueX, valueY, barWidth - 2, height);
	      int labelWidth = labelFontMetrics.stringWidth(sNames[i]);
	      x = i * barWidth + (barWidth - labelWidth) / 2;
	      g.drawString(sNames[i], x, y);
	    }
	  }

}
