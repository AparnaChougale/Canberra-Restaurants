// Author: Aparna Chougale
// Date created: 13 April 2017
// Date last changed: 14 April 2017
// This program calculates number of days a person have been alive from date of birth to second date.
// Input: user entered input via jText Fields, Output: days alive displays on jLabel after clicking "Calculate" Button.


import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;

public class Stage2 {

	// Global constants
	public static final int iWidth=158, iHeight=25;
	public static final Font fFontLabel= new Font("Tahoma", Font.BOLD, 12);
	int month[]={0,31,28,31,30,31,30,31,31,30,31,30,31};
	
	//Swing Element
	private JFrame jFrameStage2;
	private JTextField jTextFieldDateofBirth;
	private JTextField jTextFieldSecondDate;
	private JTextField jTextFieldName;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Stage2 window = new Stage2();
					window.jFrameStage2.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Stage2() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		jFrameStage2 = new JFrame();
		jFrameStage2.setBounds(100, 100, 483, 368);
		jFrameStage2.setTitle("Days Alive Calculator - Stage 2");
		jFrameStage2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jFrameStage2.getContentPane().setLayout(null);
		
		JLabel jLabelDateOfBirth = new JLabel("Date of Birth :");
		jLabelDateOfBirth.setFont(fFontLabel);
		jLabelDateOfBirth.setBounds(115, 84, 103, 29);
		jFrameStage2.getContentPane().add(jLabelDateOfBirth);
		
		JLabel jLabelSecondDate = new JLabel("Second Date :");
		jLabelSecondDate.setFont(fFontLabel);
		jLabelSecondDate.setBounds(115, 147, 92, 29);
		jFrameStage2.getContentPane().add(jLabelSecondDate);
		
		JLabel jLabelDaysAlive = new JLabel("Days Alive :");
		jLabelDaysAlive.setForeground(Color.BLUE);
		jLabelDaysAlive.setFont(new Font("Tahoma", Font.BOLD, 14));
		jLabelDaysAlive.setBounds(115, 205, 103, 29);
		jFrameStage2.getContentPane().add(jLabelDaysAlive);
		
		JLabel jLabelDaysAliveResult = new JLabel("0");
		jLabelDaysAliveResult.setForeground(Color.MAGENTA);
		jLabelDaysAliveResult.setFont(new Font("Tahoma", Font.BOLD, 16));
		jLabelDaysAliveResult.setBounds(218, 205, 103, 29);
		jFrameStage2.getContentPane().add(jLabelDaysAliveResult);
		
		jTextFieldDateofBirth = new JTextField();
		jTextFieldDateofBirth.setToolTipText("");
		jTextFieldDateofBirth.setFont(new Font("Tahoma", Font.PLAIN, 12));
		jTextFieldDateofBirth.setBounds(218, 88, iWidth, iHeight);
		jFrameStage2.getContentPane().add(jTextFieldDateofBirth);
		jTextFieldDateofBirth.setColumns(10);
		
		jTextFieldSecondDate = new JTextField();
		jTextFieldSecondDate.setFont(new Font("Tahoma", Font.PLAIN, 12));
		jTextFieldSecondDate.setBounds(218, 151, iWidth, iHeight);
		jFrameStage2.getContentPane().add(jTextFieldSecondDate);
		jTextFieldSecondDate.setColumns(10);
		
		JLabel jLabelFormateDt_1 = new JLabel("(DD/MM/YYYY)");
		jLabelFormateDt_1.setEnabled(false);
		jLabelFormateDt_1.setFont(new Font("Tahoma", Font.PLAIN, 11));
		jLabelFormateDt_1.setBounds(218, 113, 78, 19);
		jFrameStage2.getContentPane().add(jLabelFormateDt_1);
		
		JLabel jLabelFormateDt_2 = new JLabel("(DD/MM/YYYY)");
		jLabelFormateDt_2.setEnabled(false);
		jLabelFormateDt_2.setBounds(218, 175, 78, 19);
		jFrameStage2.getContentPane().add(jLabelFormateDt_2);
		
		JLabel jLabelPersonName = new JLabel("Person Name :");
		jLabelPersonName.setFont(fFontLabel);
		jLabelPersonName.setBounds(115, 38, 103, 25);
		jFrameStage2.getContentPane().add(jLabelPersonName);
		
		jTextFieldName = new JTextField();
		jTextFieldName.setFont(new Font("Tahoma", Font.PLAIN, 12));
		jTextFieldName.setBounds(218, 38, 158, 25);
		jFrameStage2.getContentPane().add(jTextFieldName);
		jTextFieldName.setColumns(10);

		
		//Calculate jButton with Event Handler
		JButton jButtomCalculateNumberOf = new JButton("Calculate");
		jButtomCalculateNumberOf.setFont(new Font("Tahoma", Font.BOLD, 14));
		jButtomCalculateNumberOf.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0)
			{
				
				 // class object
				Stage1 obj = new Stage1();
				
			
				// calculate number of days alive from birth date to second date      
						// read date of birth from jTextField
				        String date1=jTextFieldDateofBirth.getText().trim();
				        int iTemp1,iTemp2;
				 
				        //extracting day1
				        iTemp1=date1.indexOf("/");
				        int iDay1=Integer.parseInt(date1.substring(0,iTemp1));
				 
				        //extracting month1
				        iTemp2=date1.lastIndexOf("/");
				        int iMonth1=Integer.parseInt(date1.substring(iTemp1+1,iTemp2));
				 
				        //extracting year1
				        int iYear1=Integer.parseInt(date1.substring(iTemp2+1));
				 

				        // read second date from second jTextfield
				        String date2=jTextFieldSecondDate.getText().trim();
				        
				        //extracting the second date
				        iTemp1=date2.indexOf("/");
				        int iDay2=Integer.parseInt(date2.substring(0,iTemp1));
				        iTemp2=date2.lastIndexOf("/");
				        int iMonth2=Integer.parseInt(date2.substring(iTemp1+1,iTemp2));
				        int iYear2=Integer.parseInt(date2.substring(iTemp2+1));
				 
				        //Validating both dates
				        if(obj.dateValidate(iDay1,iMonth1,iYear1)==true && obj.dateValidate(iDay2,iMonth2,iYear2)==true)
				        {
				            int iDate1=obj.Days(iDay1,iMonth1,iYear1);
				            int iDate2=obj.Days(iDay2,iMonth2,iYear2);
				            int iDaysAlive= (Math.abs(iDate1-iDate2))+1;
				           // iDaysAlive+" days.";
				            jLabelDaysAliveResult.setText(String.valueOf(iDaysAlive));
				            
				        }
				        else
				            System.out.println("Invalid Date");
			}
		});
		jButtomCalculateNumberOf.setBounds(166, 259, 103, 39);
		jFrameStage2.getContentPane().add(jButtomCalculateNumberOf);
		
		// Quit Button to exit program 		
		JButton jButtomQuit = new JButton("Quit");
		jButtomQuit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		jButtomQuit.setFont(new Font("Tahoma", Font.BOLD, 14));
		jButtomQuit.setBounds(296, 259, 103, 39);
		jFrameStage2.getContentPane().add(jButtomQuit);
		
		
	}


	//function to check for Leap Year
		int isLeap(int iYear)
		    {
		        if((iYear%400==0) || ((iYear%100!=0)&&(iYear%4==0)))
		            return 29;
		        else
		            return 28;
		    }
		 
		
		//function for date validation  
		boolean dateValidate(int iDate, int iMonth, int iYear)
		    {
		        month[2]=isLeap(iYear);
		        if(iMonth<0 || iMonth>12 || iDate<0 || iDate>month[iMonth] || iYear<0 || iYear>9999)
		            return false;
		        else
		            return true;
		    }
		 
		
		//function for calculating number of days from Birth year to Second date year.
		int Days(int iDate, int iMonth, int iYear)
		    {
		        int iDays=0;
		        month[2]=isLeap(iYear);
		        for(int i=1;i<iMonth;i++)
		        {
		        	iDays=iDays+month[i];
		        }
		        iDays=iDays+iDate;
		        for(int i=1;i<iYear;i++)
		        {
		            if(isLeap(i)==29)
		            	iDays=iDays+366;
		            else
		            	iDays=iDays+365;
		        }
		        return iDays;
		    }
		 










}
